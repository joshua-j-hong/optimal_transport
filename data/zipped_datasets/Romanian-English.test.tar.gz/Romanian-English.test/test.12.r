<s snum=0027> " din considerente umanitare " , presedintele Ion Iliescu a gratiat trei ofiteri care au dat ordin soldatilor sa traga asupra multimii de pe Calea Lipovei , din Timisoara . </s>
<s snum=0028> atunci , pe 17 decembrie 1989 , in respectivul loc au murit sapte persoane si au fost ranite 40 . </s>
<s snum=0029> dupa caderea lui Ceausescu , ofiterii , alaturi de multi altii , au fost arestati . </s>
<s snum=0030> la vreo instanta de judecata ? </s>
<s snum=0031> din moment ce nu mai rezista nici ce hotaraste Curtea Suprema de Justitie , nu mai ramine decit Cel de Sus . </s>
<s snum=0032> numai ca Dumnezeu nu elibereaza hirtie de confirmare de primire a recursurilor si nici nu spune cind va da un raspuns . </s>
<s snum=0033> singura Curte de Apel , ultima si cea de pe urma instanta care nu se lasa influentata nici de gratierile " din considerente umanitare " ale presedintelui Ion Iliescu , este Istoria Romaniei . </s>
<s snum=0034> intr - o buna zi ( daca nu se pregateste masluirea ei inca de pe acum ) ea va da o sentinta definitiva ! </s>
